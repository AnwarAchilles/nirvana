<?php



class Exception extends Exception
{}